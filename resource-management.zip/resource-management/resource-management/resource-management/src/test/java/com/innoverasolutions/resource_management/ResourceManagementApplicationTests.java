package com.innoverasolutions.resource_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResourceManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
